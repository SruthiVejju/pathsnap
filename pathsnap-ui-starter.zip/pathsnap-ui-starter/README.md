# PathSnap – Teammate 1: UI and Visuals

This contribution provides the evaluator-facing React dashboard, Folium map utilities, reproducible training-partition EDA figures, and the proposed UI-to-FastAPI integration contract.

## Repository responsibilities

- `frontend/`: React + Vite evaluator interface, trip selector, route map and operational summary cards.
- `visualizations/map_preview.py`: Folium map for raw GPS observations from one permitted development trip.
- `visualizations/eda_plots.py`: EDA figures derived from `.track` files in the training partition.
- `docs/ui-api-contract.md`: proposed response contract to agree with the backend owner.
- `docs/visuals-checklist.md`: remaining visual deliverables and evidence checklist.

## Frontend

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

Set `VITE_API_BASE_URL` in `frontend/.env` to the Laptop 1 FastAPI address. The UI expects `GET /health`, `GET /trips`, and `POST /predict/{trip_id}`. These are a proposed contract, not existing endpoints; agree with the backend owner before integration. For two-laptop use, the API server must bind to `0.0.0.0` and both laptops must be on a reachable network. Configure CORS on the API for the UI origin.

## Data layout expected by visualization scripts

Extract the provided dataset so it resembles:

```text
Student folder/
├── train/
│   └── <trip_id>/
│       ├── <trip_id>.track
│       ├── <trip_id>.nodes
│       ├── <trip_id>.arcs
│       └── <trip_id>.route
└── student_test/
    └── ...
```

## EDA figures (training partition only)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r visualizations/requirements.txt
python visualizations/eda_plots.py \
  --dataset-root "/path/to/Student folder" \
  --output-dir visualizations/output/eda
```

The script reads only `train/*/*.track`, does not read `.route` files and saves observation-count, timestamp-gap and representative-trajectory figures plus a CSV summary.

## Folium raw GPS preview

```bash
python visualizations/map_preview.py \
  --track "/path/to/Student folder/train/<trip_id>/<trip_id>.track" \
  --output visualizations/output/raw_gps_preview.html
```

The map currently shows raw observations only. Predicted-route and road-network overlays are added after the backend and graph modules agree on their geometry format.

## Data and evaluation integrity

- Do not put evaluator ground-truth routes or labels in the browser response, frontend, screenshots or UI maps.
- The trip list should be supplied by the server. The provided student ZIP contains the training and student-testing partitions; use student-testing trips for development checks only.
- Do not claim model accuracy in the UI unless a permitted evaluation process explicitly returns that metric without exposing hidden labels.
- Dataset files store longitude first; Leaflet/Folium point arrays are latitude first. Convert carefully.
- Generated map HTML and EDA output files should be ignored by Git; commit source code and selected report-ready figures only when appropriate.
