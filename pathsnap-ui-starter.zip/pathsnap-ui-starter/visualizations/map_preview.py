"""Generate an interactive Folium preview for a single permitted development trip.

Coordinate convention in this script: input tables store [longitude, latitude].
Folium expects [latitude, longitude]. Do not pass evaluator ground-truth routes
into the evaluator-facing prediction map.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import folium
import pandas as pd


def read_track(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path, sep=r"\s+", header=None, names=["longitude", "latitude", "timestamp"])
    if frame.empty:
        raise ValueError(f"No GPS observations found in {path}")
    frame = frame.apply(pd.to_numeric, errors="coerce").dropna()
    valid = frame["longitude"].between(-180, 180) & frame["latitude"].between(-90, 90)
    frame = frame.loc[valid].sort_values("timestamp").reset_index(drop=True)
    if frame.empty:
        raise ValueError("No valid GPS coordinates remain after validation")
    return frame


def generate_map(track_path: Path, output_path: Path) -> None:
    gps = read_track(track_path)
    points = gps[["latitude", "longitude"]].values.tolist()
    center = [float(gps.latitude.mean()), float(gps.longitude.mean())]
    m = folium.Map(location=center, zoom_start=14, control_scale=True, tiles="OpenStreetMap")
    raw_layer = folium.FeatureGroup(name="Raw GPS observations", show=True)
    folium.PolyLine(points, color="#e5a23b", weight=2, opacity=0.7, dash_array="5, 7").add_to(raw_layer)
    for i, point in enumerate(points):
        folium.CircleMarker(point, radius=3, color="#d48b24", fill=True, fill_color="#f4bd61",
                            fill_opacity=0.85, tooltip=f"GPS observation {i + 1}").add_to(raw_layer)
    raw_layer.add_to(m)
    folium.LayerControl(collapsed=False).add_to(m)
    m.fit_bounds(points)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    m.save(str(output_path))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--track", required=True, type=Path, help="Path to a .track file from train or student_test")
    parser.add_argument("--output", default=Path("visualizations/output/raw_gps_preview.html"), type=Path)
    args = parser.parse_args()
    generate_map(args.track, args.output)
    print(f"Saved map to {args.output.resolve()}")


if __name__ == "__main__":
    main()
